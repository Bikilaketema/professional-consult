const bcrypt = require("bcrypt");
const Admin = require("./Models/Admin"); // Adjust the path if necessary

(async () => {
    try {
        const username = "bikila"; // Replace with the desired username
        const plainPassword = "bikila"; // Replace with the desired password

        // Hash the password
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(plainPassword, saltRounds);

        // Insert the admin into the database
        const newAdmin = await Admin.create({
            username,
            password: hashedPassword,
        });

        console.log("Admin registered successfully:", newAdmin);
    } catch (error) {
        console.error("Error registering admin:", error);
    } finally {
        process.exit(); // Exit the script
    }
})();